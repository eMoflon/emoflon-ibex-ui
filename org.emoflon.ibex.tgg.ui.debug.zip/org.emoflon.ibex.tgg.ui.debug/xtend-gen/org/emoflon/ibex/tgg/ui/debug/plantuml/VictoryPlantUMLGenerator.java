package org.emoflon.ibex.tgg.ui.debug.plantuml;

import java.util.Collection;
import java.util.Map;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Pair;
import org.emoflon.ibex.tgg.ui.debug.api.IMatchAdapter;
import org.emoflon.ibex.tgg.ui.debug.api.IRuleAdapter;
import org.emoflon.ibex.tgg.ui.debug.options.IBeXOp;
import org.emoflon.ibex.tgg.ui.debug.options.IUserOptions;

@SuppressWarnings("all")
public class VictoryPlantUMLGenerator {
  public static String visualiseTGGRule(final IRuleAdapter rule, final IUserOptions userOptions) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("@startuml");
    _builder.newLine();
    String _plantUMLPreamble = VictoryPlantUMLGenerator.plantUMLPreamble();
    _builder.append(_plantUMLPreamble);
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    String _visualiseRule = VictoryPlantUMLGenerator.visualiseRule(rule, false, true, userOptions.getOp());
    _builder.append(_visualiseRule);
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("@enduml");
    _builder.newLine();
    return _builder.toString();
  }
  
  public static String visualiseMatch(final IMatchAdapter match, final IRuleAdapter rule, final Collection<Object> matchNeighborhood, final IUserOptions userOptions) {
    throw new Error("Unresolved compilation problems:"
      + "\nEObject cannot be resolved to a type."
      + "\nThe method or field domainType is undefined for the type IRuleNodeAdapter"
      + "\nThe method or field DomainType is undefined"
      + "\nThe method idForNode(TGGRuleNode) from the type VictoryPlantUMLGenerator refers to the missing type TGGRuleNode"
      + "\nThe method idForNode(TGGRuleNode) from the type VictoryPlantUMLGenerator refers to the missing type TGGRuleNode"
      + "\nThe method labelFor(EObject) from the type VictoryPlantUMLGenerator refers to the missing type EObject"
      + "\nThe method indexFor(EObject) from the type VictoryPlantUMLGenerator refers to the missing type EObject"
      + "\nThe method labelFor(EObject) from the type VictoryPlantUMLGenerator refers to the missing type EObject"
      + "\nThe method indexFor(EObject) from the type VictoryPlantUMLGenerator refers to the missing type EObject"
      + "\nThe method visualiseEObjectGraph(Map<EObject, Pair<String, String>>) from the type VictoryPlantUMLGenerator refers to the missing type EObject"
      + "\n!== cannot be resolved"
      + "\nCORR cannot be resolved"
      + "\neClass cannot be resolved"
      + "\nname cannot be resolved");
  }
  
  private static String plantUMLPreamble() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("hide empty members");
    _builder.newLine();
    _builder.append("hide circle");
    _builder.newLine();
    _builder.append("hide stereotype");
    _builder.newLine();
    _builder.newLine();
    _builder.append("skinparam shadowing false");
    _builder.newLine();
    _builder.newLine();
    _builder.append("skinparam class {");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("BorderColor<<CREATE>> SpringGreen");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("BorderColor<<TRANSLATE>> Gold");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("BorderColor<<OTHER>> Black");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("BackgroundColor<<TRG>> MistyRose");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("BackgroundColor<<SRC>> LightYellow");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("BackgroundColor<<CORR>> LightCyan ");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("ArrowColor Black");
    _builder.newLine();
    _builder.append("}\t");
    _builder.newLine();
    return _builder.toString();
  }
  
  private static String visualiseRule(final IRuleAdapter rule, final boolean groupFullRule, final boolean showCreated, final IBeXOp op) {
    throw new Error("Unresolved compilation problems:"
      + "\nTGGRuleCorr cannot be resolved to a type."
      + "\nThe method or field domainType is undefined for the type IRuleNodeAdapter"
      + "\nThe method or field DomainType is undefined"
      + "\nThe method or field DomainType is undefined"
      + "\nThe method or field bindingType is undefined for the type IRuleNodeAdapter"
      + "\nThe method or field BindingType is undefined"
      + "\nThe method or field bindingType is undefined for the type IRuleNodeAdapter"
      + "\nThe method or field domainType is undefined for the type IRuleNodeAdapter"
      + "\nThe method or field DomainType is undefined"
      + "\nThe method or field DomainType is undefined"
      + "\nThe method or field bindingType is undefined for the type IRuleNodeAdapter"
      + "\nThe method or field BindingType is undefined"
      + "\nThe method or field bindingType is undefined for the type IRuleNodeAdapter"
      + "\nThe method or field domainType is undefined for the type IRuleNodeAdapter"
      + "\nThe method or field DomainType is undefined"
      + "\nThe method or field DomainType is undefined"
      + "\nThe method or field BindingType is undefined"
      + "\nThe method or field BindingType is undefined"
      + "\nThe method or field edges is undefined for the type IRuleAdapter"
      + "\nThe method or field DomainType is undefined"
      + "\nThe method or field BindingType is undefined"
      + "\nThe method or field BindingType is undefined"
      + "\nInvalid number of arguments. The method idForNode(TGGRuleNode) is not applicable without arguments"
      + "\nThe method idForNode(TGGRuleNode) from the type VictoryPlantUMLGenerator refers to the missing type TGGRuleNode"
      + "\nThe method idForNode(TGGRuleNode) from the type VictoryPlantUMLGenerator refers to the missing type TGGRuleNode"
      + "\nThe method getColorDefinitions(BindingType, DomainType, IBeXOp) from the type VictoryPlantUMLGenerator refers to the missing type BindingType"
      + "\nThe method getColorDefinitions(BindingType, DomainType, IBeXOp) from the type VictoryPlantUMLGenerator refers to the missing type BindingType"
      + "\nSRC cannot be resolved"
      + "\nSRC cannot be resolved"
      + "\n!== cannot be resolved"
      + "\nCREATE cannot be resolved"
      + "\nTRG cannot be resolved"
      + "\nTRG cannot be resolved"
      + "\n!== cannot be resolved"
      + "\nCREATE cannot be resolved"
      + "\nCORR cannot be resolved"
      + "\nCORR cannot be resolved"
      + "\nbindingType cannot be resolved"
      + "\n!== cannot be resolved"
      + "\nCREATE cannot be resolved"
      + "\nsource cannot be resolved"
      + "\ntarget cannot be resolved"
      + "\ntype cannot be resolved"
      + "\nname cannot be resolved"
      + "\nbindingType cannot be resolved"
      + "\n=== cannot be resolved"
      + "\nCREATE cannot be resolved"
      + "\ndomainType cannot be resolved"
      + "\n!== cannot be resolved"
      + "\nCORR cannot be resolved"
      + "\n&& cannot be resolved"
      + "\nbindingType cannot be resolved"
      + "\n!== cannot be resolved"
      + "\nCREATE cannot be resolved"
      + "\nsrcNode cannot be resolved"
      + "\ntrgNode cannot be resolved"
      + "\ntype cannot be resolved"
      + "\nname cannot be resolved"
      + "\nbindingType cannot be resolved"
      + "\n=== cannot be resolved"
      + "\nCREATE cannot be resolved");
  }
  
  private static String visualiseEObjectGraph(final /* Map<EObject, Pair<String, String>> */Object eObjectMapping) {
    throw new Error("Unresolved compilation problems:"
      + "\nEAttribute cannot be resolved to a type."
      + "\neClass cannot be resolved"
      + "\nEAttributes cannot be resolved"
      + "\nEType cannot be resolved"
      + "\nname cannot be resolved"
      + "\nname cannot be resolved"
      + "\neGet cannot be resolved"
      + "\neContents cannot be resolved"
      + "\neContainingFeature cannot be resolved"
      + "\nname cannot be resolved");
  }
  
  private static String labelFor(final /* EObject */Object object) {
    throw new Error("Unresolved compilation problems:"
      + "\neContainingFeature cannot be resolved"
      + "\n!== cannot be resolved"
      + "\neContainingFeature cannot be resolved"
      + "\ngetName cannot be resolved");
  }
  
  private static String indexFor(final /* EObject */Object object) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method indexFor(EObject) from the type VictoryPlantUMLGenerator refers to the missing type EObject"
      + "\neContainer cannot be resolved"
      + "\n=== cannot be resolved"
      + "\neResource cannot be resolved"
      + "\ngetResourceSet cannot be resolved"
      + "\ngetResources cannot be resolved"
      + "\nindexOf cannot be resolved"
      + "\n+ cannot be resolved"
      + "\n+ cannot be resolved"
      + "\ngetContents cannot be resolved"
      + "\nindexOf cannot be resolved"
      + "\neContainer cannot be resolved"
      + "\neContents cannot be resolved"
      + "\nindexOf cannot be resolved");
  }
  
  private static String visualiseRuleNode(final String ruleId, final String colorDefinitions) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("class ");
    _builder.append(ruleId);
    _builder.append(" ");
    _builder.append(colorDefinitions);
    return _builder.toString();
  }
  
  private static String visualiseRuleEdge(final String srcNodeId, final String trgNodeId, final String edgeId, final boolean bindingTypeCreate) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append(srcNodeId);
    _builder.append(" -");
    {
      if (bindingTypeCreate) {
        _builder.append("[#SpringGreen]");
      }
    }
    _builder.append("-> ");
    _builder.append(trgNodeId);
    _builder.append(" : \"");
    _builder.append(edgeId);
    _builder.append("\"");
    return _builder.toString();
  }
  
  private static String visualiseRuleCorrEdge(final String srcNodeId, final String trgNodeId, final String edgeId, final boolean bindingTypeCreate) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append(srcNodeId);
    _builder.append(" ...");
    {
      if (bindingTypeCreate) {
        _builder.append("[#SpringGreen]");
      }
    }
    _builder.append(" ");
    _builder.append(trgNodeId);
    _builder.append(" : \"");
    _builder.append(edgeId);
    _builder.append("\"");
    return _builder.toString();
  }
  
  private static String idForNode(final /* TGGRuleNode */Object node) {
    throw new Error("Unresolved compilation problems:"
      + "\nname cannot be resolved"
      + "\ntype cannot be resolved"
      + "\nname cannot be resolved");
  }
  
  private static String getColorDefinitions(final /* BindingType */Object binding, final /* DomainType */Object domain, final IBeXOp op) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method or field BindingType is undefined"
      + "\nThe method or field DomainType is undefined"
      + "\nThe method or field DomainType is undefined"
      + "\n=== cannot be resolved"
      + "\nCREATE cannot be resolved"
      + "\n=== cannot be resolved"
      + "\nSRC cannot be resolved"
      + "\n=== cannot be resolved"
      + "\nTRG cannot be resolved");
  }
}
