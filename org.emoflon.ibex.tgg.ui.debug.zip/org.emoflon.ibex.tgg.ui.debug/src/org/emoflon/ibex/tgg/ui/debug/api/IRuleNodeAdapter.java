package org.emoflon.ibex.tgg.ui.debug.api;


//import org.emoflon.ibex.tgg.ui.debug.adapter.TGGAdpater.BindingTypeAdapter;
public interface IRuleNodeAdapter {
	String getName();

	//DomainTypeAdapter getDomainType();
	//BindingTypeAdapter getBindingType();

	
}
