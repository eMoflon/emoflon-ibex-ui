package org.emoflon.ibex.tgg.ui.debug.api;

import java.util.Collection;

//import org.emoflon.ibex.tgg.ui.debug.adapter.TGGAdpater.MatchAdapter;

public interface IMatchAdapter {
	
	 String getRuleName() ;
	 Collection<String> getParameterNames();
	 Object get(String name);
	
}
