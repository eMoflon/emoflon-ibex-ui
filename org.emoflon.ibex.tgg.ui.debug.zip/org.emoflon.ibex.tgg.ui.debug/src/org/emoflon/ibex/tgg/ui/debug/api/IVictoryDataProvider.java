package org.emoflon.ibex.tgg.ui.debug.api;

import java.io.IOException;
import java.util.Set;

public interface IVictoryDataProvider {
    public IRuleAdapter getRule(String pRuleName); 
    public Set<IMatchAdapter> getMatches();
    public Set<IMatchAdapter> getMatches(IMatchAdapter match);
	public Set<IMatchAdapter> getMatches(String pRuleName);
    public Set<Object> getMatchNeighbourhood(IMatchAdapter match, int k);
    abstract public void saveModels() throws IOException;
}
