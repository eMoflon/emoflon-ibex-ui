package org.emoflon.ibex.tgg.ui.debug.api;

import java.util.List;

import org.eclipse.emf.common.util.EList;



public interface IRuleAdapter {
	
 List<IRuleNodeAdapter> getNodes();
}
