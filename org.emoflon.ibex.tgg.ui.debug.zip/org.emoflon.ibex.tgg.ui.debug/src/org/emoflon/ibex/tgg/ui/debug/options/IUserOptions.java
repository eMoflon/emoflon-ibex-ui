package org.emoflon.ibex.tgg.ui.debug.options;

public interface IUserOptions {

    public boolean displayFullRuleForMatches();

    public IBeXOp getOp();
}
