package org.emoflon.ibex.tgg.ui.debug.options;

public enum IBeXOp {
    MODELGEN, INITIAL_FWD, INITIAL_BWD;
}
